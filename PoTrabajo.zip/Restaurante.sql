-- Restaurante.sql - SQL Server
IF DB_ID('Restaurante') IS NULL
    CREATE DATABASE Restaurante;
GO
USE Restaurante;
GO

IF OBJECT_ID('DetallePedido') IS NOT NULL DROP TABLE DetallePedido;
IF OBJECT_ID('Pedidos') IS NOT NULL DROP TABLE Pedidos;
IF OBJECT_ID('Platillos') IS NOT NULL DROP TABLE Platillos;
IF OBJECT_ID('Clientes') IS NOT NULL DROP TABLE Clientes;
GO

CREATE TABLE Clientes (
    id_cliente INT IDENTITY(1,1) PRIMARY KEY,
    nombre NVARCHAR(100) NOT NULL,
    correo NVARCHAR(100) NOT NULL
);

CREATE TABLE Platillos (
    id_platillo INT IDENTITY(1,1) PRIMARY KEY,
    nombre NVARCHAR(100) NOT NULL UNIQUE,
    precio DECIMAL(10,2) NOT NULL CHECK (precio > 0)
);

CREATE TABLE Pedidos (
    id_pedido INT IDENTITY(1,1) PRIMARY KEY,
    id_cliente INT NOT NULL,
    fecha DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Pedidos_Cliente FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente)
);

CREATE TABLE DetallePedido (
    id_detalle INT IDENTITY(1,1) PRIMARY KEY,
    id_pedido INT NOT NULL,
    id_platillo INT NOT NULL,
    cantidad INT NOT NULL CHECK (cantidad > 0),
    CONSTRAINT FK_Detalle_Pedido FOREIGN KEY (id_pedido) REFERENCES Pedidos(id_pedido) ON DELETE CASCADE,
    CONSTRAINT FK_Detalle_Platillo FOREIGN KEY (id_platillo) REFERENCES Platillos(id_platillo)
);

-- Datos de prueba
INSERT INTO Clientes (nombre, correo) VALUES
('Juan Pérez', 'juan@example.com'),
('María López', 'maria@example.com');

INSERT INTO Platillos (nombre, precio) VALUES
('Tacos al pastor', 50.00),
('Enchiladas verdes', 70.00),
('Sopa azteca', 45.00);

-- Pedido de ejemplo
DECLARE @idCliente INT = (SELECT TOP 1 id_cliente FROM Clientes ORDER BY id_cliente);
INSERT INTO Pedidos (id_cliente) VALUES (@idCliente);
DECLARE @idPedido INT = SCOPE_IDENTITY();
INSERT INTO DetallePedido (id_pedido, id_platillo, cantidad)
SELECT @idPedido, id_platillo, 1 FROM Platillos WHERE nombre IN ('Tacos al pastor','Enchiladas verdes');

-- Vista para reportes
IF OBJECT_ID('vw_PedidosPorCliente') IS NOT NULL DROP VIEW vw_PedidosPorCliente;
GO
CREATE VIEW vw_PedidosPorCliente AS
SELECT c.id_cliente, c.nombre AS cliente, p.id_pedido, p.fecha,
       SUM(dp.cantidad * pl.precio) AS total_pedido
FROM Clientes c
JOIN Pedidos p ON p.id_cliente = c.id_cliente
JOIN DetallePedido dp ON dp.id_pedido = p.id_pedido
JOIN Platillos pl ON pl.id_platillo = dp.id_platillo
GROUP BY c.id_cliente, c.nombre, p.id_pedido, p.fecha;
GO

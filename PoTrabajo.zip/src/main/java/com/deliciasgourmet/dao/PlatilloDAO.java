package com.deliciasgourmet.dao;

import com.deliciasgourmet.conexion.Conexion;
import com.deliciasgourmet.modelo.Platillo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;

public class PlatilloDAO {

    public void insertar(Platillo p) throws SQLException {
        String sql = "INSERT INTO Platillos(nombre, precio) VALUES(?,?)";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setBigDecimal(2, p.getPrecio());
            ps.executeUpdate();
        }
    }

    public void actualizar(Platillo p) throws SQLException {
        String sql = "UPDATE Platillos SET nombre=?, precio=? WHERE id_platillo=?";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setBigDecimal(2, p.getPrecio());
            ps.setInt(3, p.getIdPlatillo());
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM Platillos WHERE id_platillo=?";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Platillo> listar() throws SQLException {
        List<Platillo> lista = new ArrayList<>();
        String sql = "SELECT id_platillo, nombre, precio FROM Platillos ORDER BY id_platillo";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Platillo(rs.getInt(1), rs.getString(2), rs.getBigDecimal(3)));
            }
        }
        return lista;
    }
}

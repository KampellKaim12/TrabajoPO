package com.deliciasgourmet.dao;

import com.deliciasgourmet.conexion.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public int crearPedido(int idCliente) throws SQLException {
        String sql = "INSERT INTO Pedidos(id_cliente) VALUES(?)";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, idCliente);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("No se pudo generar id de pedido");
    }

    public void agregarDetalle(int idPedido, int idPlatillo, int cantidad) throws SQLException {
        String sql = "INSERT INTO DetallePedido(id_pedido, id_platillo, cantidad) VALUES(?,?,?)";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idPedido);
            ps.setInt(2, idPlatillo);
            ps.setInt(3, cantidad);
            ps.executeUpdate();
        }
    }

    public void eliminarPedido(int idPedido) throws SQLException {
        try (Connection cn = Conexion.getConnection()) {
            cn.setAutoCommit(false);
            try (PreparedStatement ps1 = cn.prepareStatement("DELETE FROM DetallePedido WHERE id_pedido=?");
                 PreparedStatement ps2 = cn.prepareStatement("DELETE FROM Pedidos WHERE id_pedido=?")) {
                ps1.setInt(1, idPedido);
                ps1.executeUpdate();
                ps2.setInt(1, idPedido);
                ps2.executeUpdate();
                cn.commit();
            } catch (SQLException ex) {
                cn.rollback();
                throw ex;
            } finally {
                cn.setAutoCommit(true);
            }
        }
    }

    public List<Object[]> listarPedidosPorCliente(int idCliente) throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT p.id_pedido, p.fecha, SUM(dp.cantidad * pl.precio) AS total " +
                     "FROM Pedidos p JOIN DetallePedido dp ON dp.id_pedido=p.id_pedido " +
                     "JOIN Platillos pl ON pl.id_platillo=dp.id_platillo " +
                     "WHERE p.id_cliente=? GROUP BY p.id_pedido, p.fecha ORDER BY p.fecha DESC";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{ rs.getInt(1), rs.getTimestamp(2), rs.getBigDecimal(3) });
                }
            }
        }
        return rows;
    }
}

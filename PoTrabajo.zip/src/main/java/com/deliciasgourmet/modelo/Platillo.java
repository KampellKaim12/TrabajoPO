package com.deliciasgourmet.modelo;

import java.math.BigDecimal;

public class Platillo {
    private int idPlatillo;
    private String nombre;
    private BigDecimal precio;

    public Platillo() {}

    public Platillo(int idPlatillo, String nombre, BigDecimal precio) {
        this.idPlatillo = idPlatillo;
        this.nombre = nombre;
        this.precio = precio;
    }

    public int getIdPlatillo() { return idPlatillo; }
    public void setIdPlatillo(int idPlatillo) { this.idPlatillo = idPlatillo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal precio) { this.precio = precio; }

    @Override
    public String toString() { return nombre; }
}

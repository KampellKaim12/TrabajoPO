package com.deliciasgourmet.ui;

import com.deliciasgourmet.dao.ClienteDAO;
import com.deliciasgourmet.dao.PedidoDAO;
import com.deliciasgourmet.modelo.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class FrmReportes extends JDialog {
    private final JComboBox<Cliente> cmbCliente = new JComboBox<>();
    private final JTable tabla = new JTable();
    private final DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID Pedido","Fecha","Total"},0){
        public boolean isCellEditable(int r,int c){return false;}
    };
    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final PedidoDAO pedidoDAO = new PedidoDAO();

    public FrmReportes(Frame owner) {
        super(owner, "Reportes - Pedidos por cliente", true);
        setSize(700, 500);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10,10));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnBuscar = new JButton("Buscar");
        top.add(new JLabel("Cliente:"));
        top.add(cmbCliente);
        top.add(btnBuscar);

        tabla.setModel(modelo);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        btnBuscar.addActionListener(e -> cargar());
        cargarClientes();
    }

    private void cargarClientes() {
        try {
            cmbCliente.removeAllItems();
            for (var c : clienteDAO.listar()) cmbCliente.addItem(c);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargar() {
        var c = (Cliente) cmbCliente.getSelectedItem();
        if (c == null) return;
        try {
            modelo.setRowCount(0);
            for (var row : pedidoDAO.listarPedidosPorCliente(c.getIdCliente())) {
                modelo.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

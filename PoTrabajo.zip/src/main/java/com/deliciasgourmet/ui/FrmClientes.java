package com.deliciasgourmet.ui;

import com.deliciasgourmet.dao.ClienteDAO;
import com.deliciasgourmet.modelo.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class FrmClientes extends JDialog {
    private final JTextField txtNombre = new JTextField();
    private final JTextField txtCorreo = new JTextField();
    private final JTable tabla = new JTable();
    private final ClienteDAO dao = new ClienteDAO();
    private int selectedId = -1;

    public FrmClientes(Frame owner) {
        super(owner, "Clientes", true);
        setSize(700, 500);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10,10));

        var pnlForm = new JPanel(new GridLayout(2,2,8,8));
        pnlForm.add(new JLabel("Nombre:"));
        pnlForm.add(txtNombre);
        pnlForm.add(new JLabel("Correo:"));
        pnlForm.add(txtCorreo);

        var btnGuardar = new JButton("Guardar");
        var btnNuevo = new JButton("Nuevo");
        var btnEliminar = new JButton("Eliminar");

        var pnlBtns = new JPanel();
        pnlBtns.add(btnGuardar);
        pnlBtns.add(btnNuevo);
        pnlBtns.add(btnEliminar);

        var modelo = new DefaultTableModel(new Object[]{"ID","Nombre","Correo"}, 0) {
            public boolean isCellEditable(int r,int c){return false;}
        };
        tabla.setModel(modelo);
        var scroll = new JScrollPane(tabla);

        add(pnlForm, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(pnlBtns, BorderLayout.SOUTH);

        btnGuardar.addActionListener(e -> guardar());
        btnNuevo.addActionListener(e -> limpiar());
        btnEliminar.addActionListener(e -> eliminar());
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow()>=0) {
                selectedId = (Integer) tabla.getValueAt(tabla.getSelectedRow(), 0);
                txtNombre.setText((String) tabla.getValueAt(tabla.getSelectedRow(), 1));
                txtCorreo.setText((String) tabla.getValueAt(tabla.getSelectedRow(), 2));
            }
        });

        recargar();
    }

    private void recargar() {
        try {
            var modelo = (DefaultTableModel) tabla.getModel();
            modelo.setRowCount(0);
            for (var c : dao.listar()) {
                modelo.addRow(new Object[]{c.getIdCliente(), c.getNombre(), c.getCorreo()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardar() {
        var nombre = txtNombre.getText().trim();
        var correo = txtCorreo.getText().trim();
        if (nombre.isEmpty() || correo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre y correo son obligatorios");
            return;
        }
        try {
            if (selectedId == -1) {
                dao.insertar(new Cliente(0, nombre, correo));
            } else {
                dao.actualizar(new Cliente(selectedId, nombre, correo));
            }
            limpiar();
            recargar();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminar() {
        if (selectedId == -1) { JOptionPane.showMessageDialog(this, "Seleccione un cliente"); return; }
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar cliente?","Confirmar",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
            try {
                dao.eliminar(selectedId);
                limpiar();
                recargar();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiar() {
        selectedId = -1;
        txtNombre.setText("");
        txtCorreo.setText("");
        tabla.clearSelection();
    }
}

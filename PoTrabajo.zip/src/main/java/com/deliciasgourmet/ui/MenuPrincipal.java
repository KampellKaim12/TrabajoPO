package com.deliciasgourmet.ui;

import javax.swing.*;
import java.awt.*;

public class MenuPrincipal extends JFrame {

    public MenuPrincipal() {
        setTitle("Delicias Gourmet - Sistema de Restaurante");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        var barra = new JMenuBar();
        var mCatalogos = new JMenu("Catálogos");
        var mClientes = new JMenuItem("Clientes");
        var mPlatillos = new JMenuItem("Platillos");
        mCatalogos.add(mClientes);
        mCatalogos.add(mPlatillos);

        var mOper = new JMenu("Operaciones");
        var mPedidos = new JMenuItem("Pedidos");

        var mReportes = new JMenu("Reportes");
        var mRepPedidosCliente = new JMenuItem("Pedidos por cliente");

        barra.add(mCatalogos);
        barra.add(mOper);
        barra.add(mReportes);
        setJMenuBar(barra);

        var lbl = new JLabel("Sistema de Gestión de Menú y Pedidos", SwingConstants.CENTER);
        lbl.setFont(lbl.getFont().deriveFont(Font.BOLD, 22f));
        add(lbl, BorderLayout.CENTER);

        mClientes.addActionListener(e -> new FrmClientes(this).setVisible(true));
        mPlatillos.addActionListener(e -> new FrmPlatillos(this).setVisible(true));
        mPedidos.addActionListener(e -> new FrmPedidos(this).setVisible(true));
        mRepPedidosCliente.addActionListener(e -> new FrmReportes(this).setVisible(true));
        mOper.add(mPedidos);
        mReportes.add(mRepPedidosCliente);
    }
}

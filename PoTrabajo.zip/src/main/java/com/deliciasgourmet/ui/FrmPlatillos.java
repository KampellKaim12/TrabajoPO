package com.deliciasgourmet.ui;

import com.deliciasgourmet.dao.PlatilloDAO;
import com.deliciasgourmet.modelo.Platillo;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLException;

public class FrmPlatillos extends JDialog {
    private final JTextField txtNombre = new JTextField();
    private final JTextField txtPrecio = new JTextField();
    private final JTable tabla = new JTable();
    private final PlatilloDAO dao = new PlatilloDAO();
    private int selectedId = -1;

    public FrmPlatillos(Frame owner) {
        super(owner, "Platillos", true);
        setSize(700, 500);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10,10));

        var pnlForm = new JPanel(new GridLayout(2,2,8,8));
        pnlForm.add(new JLabel("Nombre:"));
        pnlForm.add(txtNombre);
        pnlForm.add(new JLabel("Precio:"));
        pnlForm.add(txtPrecio);

        var btnGuardar = new JButton("Guardar");
        var btnNuevo = new JButton("Nuevo");
        var btnEliminar = new JButton("Eliminar");

        var pnlBtns = new JPanel();
        pnlBtns.add(btnGuardar);
        pnlBtns.add(btnNuevo);
        pnlBtns.add(btnEliminar);

        var modelo = new DefaultTableModel(new Object[]{"ID","Nombre","Precio"}, 0) {
            public boolean isCellEditable(int r,int c){return false;}
        };
        tabla.setModel(modelo);
        var scroll = new JScrollPane(tabla);

        add(pnlForm, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(pnlBtns, BorderLayout.SOUTH);

        btnGuardar.addActionListener(e -> guardar());
        btnNuevo.addActionListener(e -> limpiar());
        btnEliminar.addActionListener(e -> eliminar());
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow()>=0) {
                selectedId = (Integer) tabla.getValueAt(tabla.getSelectedRow(), 0);
                txtNombre.setText((String) tabla.getValueAt(tabla.getSelectedRow(), 1));
                txtPrecio.setText(String.valueOf(tabla.getValueAt(tabla.getSelectedRow(), 2)));
            }
        });

        recargar();
    }

    private void recargar() {
        try {
            var modelo = (DefaultTableModel) tabla.getModel();
            modelo.setRowCount(0);
            for (var p : dao.listar()) {
                modelo.addRow(new Object[]{p.getIdPlatillo(), p.getNombre(), p.getPrecio()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardar() {
        var nombre = txtNombre.getText().trim();
        var precioTxt = txtPrecio.getText().trim();
        if (nombre.isEmpty() || precioTxt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre y precio son obligatorios");
            return;
        }
        try {
            var precio = new BigDecimal(precioTxt);
            if (precio.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this, "El precio debe ser mayor a cero");
                return;
            }
            if (selectedId == -1) {
                dao.insertar(new Platillo(0, nombre, precio));
            } else {
                var p = new Platillo(selectedId, nombre, precio);
                dao.actualizar(p);
            }
            limpiar();
            recargar();
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Precio inválido");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminar() {
        if (selectedId == -1) { JOptionPane.showMessageDialog(this, "Seleccione un platillo"); return; }
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar platillo?","Confirmar",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
            try {
                dao.eliminar(selectedId);
                limpiar();
                recargar();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiar() {
        selectedId = -1;
        txtNombre.setText("");
        txtPrecio.setText("");
        tabla.clearSelection();
    }
}

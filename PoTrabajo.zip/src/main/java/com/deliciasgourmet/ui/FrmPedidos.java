package com.deliciasgourmet.ui;

import com.deliciasgourmet.dao.ClienteDAO;
import com.deliciasgourmet.dao.PedidoDAO;
import com.deliciasgourmet.dao.PlatilloDAO;
import com.deliciasgourmet.modelo.Cliente;
import com.deliciasgourmet.modelo.Platillo;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class FrmPedidos extends JDialog {
    private final JComboBox<Cliente> cmbCliente = new JComboBox<>();
    private final JComboBox<Platillo> cmbPlatillo = new JComboBox<>();
    private final JSpinner spCantidad = new JSpinner(new SpinnerNumberModel(1,1,999,1));
    private final JTable tabla = new JTable();
    private final DefaultTableModel modelo = new DefaultTableModel(new Object[]{"ID Platillo","Platillo","Cantidad"},0){
        public boolean isCellEditable(int r,int c){return false;}
    };
    private final Map<Integer, Integer> carrito = new LinkedHashMap<>();

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final PlatilloDAO platilloDAO = new PlatilloDAO();
    private final PedidoDAO pedidoDAO = new PedidoDAO();

    public FrmPedidos(Frame owner) {
        super(owner, "Pedidos", true);
        setSize(800, 600);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10,10));

        JPanel top = new JPanel(new GridLayout(2,3,8,8));
        top.add(new JLabel("Cliente:"));
        top.add(new JLabel("Platillo:"));
        top.add(new JLabel("Cantidad:"));
        top.add(cmbCliente);
        top.add(cmbPlatillo);
        top.add(spCantidad);

        JButton btnAgregar = new JButton("Agregar al pedido");
        JButton btnGuardar = new JButton("Guardar pedido");
        JButton btnQuitar = new JButton("Quitar seleccionado");
        JPanel actions = new JPanel();
        actions.add(btnAgregar);
        actions.add(btnQuitar);
        actions.add(btnGuardar);

        tabla.setModel(modelo);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> agregar());
        btnQuitar.addActionListener(e -> quitar());
        btnGuardar.addActionListener(e -> guardar());

        cargarCombos();
    }

    private void cargarCombos() {
        try {
            cmbCliente.removeAllItems();
            for (var c : clienteDAO.listar()) cmbCliente.addItem(c);
            cmbPlatillo.removeAllItems();
            for (var p : platilloDAO.listar()) cmbPlatillo.addItem(p);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregar() {
        Platillo p = (Platillo) cmbPlatillo.getSelectedItem();
        int cant = (Integer) spCantidad.getValue();
        if (p == null) { JOptionPane.showMessageDialog(this, "Seleccione un platillo"); return; }
        carrito.merge(p.getIdPlatillo(), cant, Integer::sum);
        refrescarTabla();
    }

    private void quitar() {
        int row = tabla.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Seleccione una fila"); return; }
        int idPlat = (Integer) modelo.getValueAt(row, 0);
        carrito.remove(idPlat);
        refrescarTabla();
    }

    private void refrescarTabla() {
        modelo.setRowCount(0);
        for (var entry : carrito.entrySet()) {
            int idPlat = entry.getKey();
            int cant = entry.getValue();
            Platillo pSel = null;
            for (int i=0;i<cmbPlatillo.getItemCount();i++) {
                var p = cmbPlatillo.getItemAt(i);
                if (p.getIdPlatillo()==idPlat) { pSel = p; break; }
            }
            if (pSel!=null) modelo.addRow(new Object[]{idPlat, pSel.getNombre(), cant});
        }
    }

    private void guardar() {
        if (cmbCliente.getSelectedItem()==null) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente"); return;
        }
        if (carrito.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El pedido no puede estar vacío"); return;
        }
        try {
            int idCliente = ((Cliente)cmbCliente.getSelectedItem()).getIdCliente();
            int idPedido = pedidoDAO.crearPedido(idCliente);
            for (var e : carrito.entrySet()) {
                pedidoDAO.agregarDetalle(idPedido, e.getKey(), e.getValue());
            }
            carrito.clear();
            refrescarTabla();
            JOptionPane.showMessageDialog(this, "Pedido guardado. ID: " + idPedido);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

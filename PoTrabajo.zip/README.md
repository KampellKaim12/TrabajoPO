# Delicias Gourmet - Sistema de Restaurante (SQL Server + NetBeans + FlatLaf)

## Requisitos
- JDK 17
- Apache NetBeans (o cualquier IDE compatible con Maven)
- SQL Server + SQL Server Management Studio

## Instalación
1. En SQL Server, ejecuta `Restaurante.sql` para crear la base y datos de prueba.
2. Abre este proyecto como **Proyecto Maven** en NetBeans.
3. Edita `Conexion.java` y coloca tu usuario y contraseña de SQL Server.
4. Ejecuta `MainApp`.

> Si Maven no resuelve las dependencias, actualiza las versiones en `pom.xml` a las más recientes (FlatLaf y `mssql-jdbc`).

## Funcionalidades
- CRUD de Clientes y Platillos.
- Gestión de Pedidos (carrito con cantidades).
- Reporte de pedidos por cliente con total.
- Look & Feel moderno con **FlatLaf**.

## Notas
- La vista SQL `vw_PedidosPorCliente` está disponible si deseas reportes directos desde SQL.
- La eliminación de un pedido borra sus detalles (transacción).

## Credenciales
- URL por defecto: `jdbc:sqlserver://localhost:1433;databaseName=Restaurante;encrypt=false`
- Usuario: `sa`
- Contraseña: `tu_contraseña`

